const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const DATA_FILE = './data.json';
let data = { users: {}, couples: {}, pairCodes: {}, wishes: {}, stats: {}, challenges: {}, diary: {}, mood: {}, chat: {}, secrets: {}, gifts: {}, tests: {}, calendar: {}, confessions: {} };

function loadData() { try { if (fs.existsSync(DATA_FILE)) data = JSON.parse(fs.readFileSync(DATA_FILE)); } catch(e) { console.log('Load error:', e); } }
function saveData() { try { fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); } catch(e) { console.log('Save error:', e); } }
loadData();

// DEBUG
app.get('/api/debug', (req, res) => {
  res.json({ usersCount: Object.keys(data.users).length, pairCodes: Object.keys(data.pairCodes), users: Object.keys(data.users) });
});

// AUTH
app.get('/api/user/:id/status', (req, res) => {
  const odUserId = String(req.params.id);
  console.log('Status:', odUserId);
  const user = data.users[odUserId];
  if (!user) return res.json({ registered: false });
  const partner = user.coupleId ? Object.values(data.users).find(u => u.coupleId === user.coupleId && u.id !== odUserId) : null;
  res.json({ registered: true, user, partner: partner || null });
});

app.post('/api/register', (req, res) => {
  const { odUserId, odName, odPhone } = req.body;
  const odUserIdStr = String(odUserId);
  console.log('Register:', odUserIdStr, odName);
  if (data.users[odUserIdStr]) return res.json({ success: false, error: 'exists' });
  let pairCode;
  do { pairCode = Math.random().toString(36).substring(2, 8).toUpperCase(); } while (data.pairCodes[pairCode]);
  const coupleId = 'couple_' + odUserIdStr + '_' + Date.now();
  data.users[odUserIdStr] = { id: odUserIdStr, name: odName, phone: odPhone || '', pairCode, coupleId, xp: 0, level: 1, coins: 100, created: new Date().toISOString() };
  data.pairCodes[pairCode] = odUserIdStr;
  data.couples[coupleId] = { id: coupleId, user1: odUserIdStr, user2: null, created: new Date().toISOString() };
  saveData();
  console.log('Registered with code:', pairCode);
  res.json({ success: true, user: data.users[odUserIdStr], pairCode });
});

app.post('/api/join', (req, res) => {
  const { odUserId, odName, odPhone, odPairCode } = req.body;
  const odUserIdStr = String(odUserId);
  const codeUpper = String(odPairCode || '').toUpperCase().trim();
  console.log('Join:', odUserIdStr, 'code:', codeUpper, 'available:', Object.keys(data.pairCodes));
  if (data.users[odUserIdStr]) return res.json({ success: false, error: 'exists', message: 'Вы уже зарегистрированы' });
  const partnerId = data.pairCodes[codeUpper];
  if (!partnerId) return res.json({ success: false, error: 'invalid_code', message: 'Неверный код' });
  const partner = data.users[partnerId];
  if (!partner) return res.json({ success: false, error: 'partner_not_found', message: 'Партнёр не найден' });
  if (data.couples[partner.coupleId]?.user2) return res.json({ success: false, error: 'used', message: 'Код использован' });
  data.users[odUserIdStr] = { id: odUserIdStr, name: odName, phone: odPhone || '', coupleId: partner.coupleId, xp: 0, level: 1, coins: 100, created: new Date().toISOString() };
  data.couples[partner.coupleId].user2 = odUserIdStr;
  delete data.pairCodes[codeUpper];
  saveData();
  console.log('Joined!');
  res.json({ success: true, user: data.users[odUserIdStr], partner });
});

// CHAT
app.get('/api/couple/:coupleId/chat', (req, res) => res.json(data.chat[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/chat', (req, res) => {
  const { from, message } = req.body;
  if (!data.chat[req.params.coupleId]) data.chat[req.params.coupleId] = [];
  data.chat[req.params.coupleId].push({ id: Date.now(), from: String(from), message, time: new Date().toISOString() });
  if (data.chat[req.params.coupleId].length > 500) data.chat[req.params.coupleId] = data.chat[req.params.coupleId].slice(-500);
  saveData();
  res.json({ success: true });
});

// WISHES
app.get('/api/couple/:coupleId/wishes', (req, res) => res.json(data.wishes[req.params.coupleId] || { user1: [], user2: [], matches: [] }));
app.post('/api/couple/:coupleId/wishes', (req, res) => {
  const { odUserId, wishes } = req.body;
  if (!data.wishes[req.params.coupleId]) data.wishes[req.params.coupleId] = { user1: [], user2: [], matches: [] };
  const couple = data.couples[req.params.coupleId];
  if (couple?.user1 === String(odUserId)) data.wishes[req.params.coupleId].user1 = wishes;
  else data.wishes[req.params.coupleId].user2 = wishes;
  const w1 = data.wishes[req.params.coupleId].user1, w2 = data.wishes[req.params.coupleId].user2;
  data.wishes[req.params.coupleId].matches = w1.filter(w => w2.includes(w));
  saveData();
  res.json({ success: true, wishes: data.wishes[req.params.coupleId] });
});

// TESTS
app.get('/api/couple/:coupleId/tests', (req, res) => res.json(data.tests[req.params.coupleId] || {}));
app.post('/api/couple/:coupleId/tests', (req, res) => {
  const { testId, odUserId, answers } = req.body;
  if (!data.tests[req.params.coupleId]) data.tests[req.params.coupleId] = {};
  if (!data.tests[req.params.coupleId][testId]) data.tests[req.params.coupleId][testId] = {};
  data.tests[req.params.coupleId][testId][String(odUserId)] = answers;
  saveData();
  res.json({ success: true });
});

// SECRETS
app.get('/api/couple/:coupleId/secrets', (req, res) => res.json(data.secrets[req.params.coupleId] || { p1: [], p2: [], revealed: [] }));
app.post('/api/couple/:coupleId/secrets', (req, res) => {
  const { secret, odUserId } = req.body;
  if (!data.secrets[req.params.coupleId]) data.secrets[req.params.coupleId] = { p1: [], p2: [], revealed: [] };
  const couple = data.couples[req.params.coupleId];
  const key = couple?.user1 === String(odUserId) ? 'p1' : 'p2';
  data.secrets[req.params.coupleId][key].push({ id: Date.now(), secret, added: new Date().toISOString() });
  saveData();
  res.json({ success: true });
});
app.post('/api/couple/:coupleId/secrets/reveal', (req, res) => {
  const s = data.secrets[req.params.coupleId];
  if (!s) return res.json({ success: false });
  const p1 = s.p1.filter(x => !s.revealed.includes(x.id)), p2 = s.p2.filter(x => !s.revealed.includes(x.id));
  if (!p1.length || !p2.length) return res.json({ success: false, error: 'need_both' });
  const s1 = p1[Math.floor(Math.random() * p1.length)], s2 = p2[Math.floor(Math.random() * p2.length)];
  s.revealed.push(s1.id, s2.id);
  saveData();
  res.json({ success: true, secrets: [s1, s2] });
});

// DIARY
app.get('/api/couple/:coupleId/diary', (req, res) => res.json(data.diary[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/diary', (req, res) => {
  const { title, content, mood, author } = req.body;
  if (!data.diary[req.params.coupleId]) data.diary[req.params.coupleId] = [];
  data.diary[req.params.coupleId].unshift({ id: Date.now(), title, content, mood, author, date: new Date().toISOString() });
  saveData();
  res.json({ success: true });
});

// MOOD
app.get('/api/couple/:coupleId/mood', (req, res) => res.json(data.mood[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/mood', (req, res) => {
  const { odUserId, mood } = req.body;
  if (!data.mood[req.params.coupleId]) data.mood[req.params.coupleId] = [];
  const today = new Date().toISOString().split('T')[0];
  data.mood[req.params.coupleId] = data.mood[req.params.coupleId].filter(m => !(m.odUserId === String(odUserId) && m.date.startsWith(today)));
  data.mood[req.params.coupleId].unshift({ id: Date.now(), odUserId: String(odUserId), mood, date: new Date().toISOString() });
  saveData();
  res.json({ success: true });
});

// CALENDAR
app.get('/api/couple/:coupleId/calendar', (req, res) => res.json(data.calendar[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/calendar', (req, res) => {
  const { date, type, position, mood, notes, from } = req.body;
  if (!data.calendar[req.params.coupleId]) data.calendar[req.params.coupleId] = [];
  data.calendar[req.params.coupleId].push({ id: Date.now(), date, type, position, mood, notes, from: String(from), created: new Date().toISOString() });
  saveData();
  res.json({ success: true });
});

// GIFTS
const GIFTS = [
  {id:1,name:'Роза',icon:'🌹',cost:10},{id:2,name:'Шоколад',icon:'🍫',cost:15},{id:3,name:'Сердце',icon:'❤️',cost:20},
  {id:4,name:'Мишка',icon:'🧸',cost:30},{id:5,name:'Кольцо',icon:'💍',cost:50},{id:6,name:'Букет',icon:'💐',cost:25},
  {id:7,name:'Поцелуй',icon:'💋',cost:5},{id:8,name:'Корона',icon:'👑',cost:100},{id:9,name:'Звезда',icon:'⭐',cost:40}
];
app.get('/api/gifts', (req, res) => res.json(GIFTS));
app.get('/api/couple/:coupleId/gifts', (req, res) => res.json(data.gifts[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/gifts', (req, res) => {
  const { giftId, from, to } = req.body;
  const gift = GIFTS.find(g => g.id == giftId);
  if (!gift) return res.json({ success: false });
  const user = data.users[String(from)];
  if (!user || (user.coins || 0) < gift.cost) return res.json({ success: false, error: 'no_coins' });
  user.coins -= gift.cost;
  if (!data.gifts[req.params.coupleId]) data.gifts[req.params.coupleId] = [];
  data.gifts[req.params.coupleId].push({ id: Date.now(), giftId, from: String(from), to: String(to), icon: gift.icon, name: gift.name, time: new Date().toISOString() });
  saveData();
  res.json({ success: true, user });
});

// CHALLENGES
app.get('/api/couple/:coupleId/challenges', (req, res) => res.json(data.challenges[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/challenges', (req, res) => {
  const { challenge, from } = req.body;
  if (!data.challenges[req.params.coupleId]) data.challenges[req.params.coupleId] = [];
  data.challenges[req.params.coupleId].push({ id: Date.now(), ...challenge, from: String(from), status: 'active', created: new Date().toISOString() });
  saveData();
  res.json({ success: true });
});
app.post('/api/couple/:coupleId/challenges/:id/complete', (req, res) => {
  const ch = data.challenges[req.params.coupleId]?.find(c => c.id == req.params.id);
  if (ch) { ch.status = 'completed'; ch.completedAt = new Date().toISOString(); saveData(); }
  res.json({ success: true });
});

// CONFESSIONS
app.get('/api/couple/:coupleId/confessions', (req, res) => res.json(data.confessions[req.params.coupleId] || []));
app.post('/api/couple/:coupleId/confessions', (req, res) => {
  const { confession, from } = req.body;
  if (!data.confessions[req.params.coupleId]) data.confessions[req.params.coupleId] = [];
  data.confessions[req.params.coupleId].unshift({ id: Date.now(), confession, from: String(from), time: new Date().toISOString(), read: false });
  saveData();
  res.json({ success: true });
});

// CONTENT
app.get('/api/content', (req, res) => {
  res.json({
    questionLevels: [
      {id:1,title:'Знакомство',desc:'Лёгкие вопросы',color:'l1',icon:'🌱',questions:[{q:'Какой момент сегодня был лучшим?'},{q:'В какой стране мечтаешь побывать?'},{q:'Любимое воспоминание из детства?'},{q:'Что тебя вдохновляет?'},{q:'Какую суперспособность хотел бы?'},{q:'Идеальный выходной?'},{q:'Какая песня поднимает настроение?'},{q:'Самое необычное блюдо?'},{q:'Кем мечтал стать в детстве?'},{q:'Что удивило недавно?'},{q:'Любимое время года?'},{q:'Какой фильм пересматриваешь?'},{q:'Утро или вечер?'},{q:'Море или горы?'},{q:'Какой талант хотел бы?'},{q:'Странный страх?'},{q:'Что поднимает настроение?'},{q:'Любимый праздник?'},{q:'Какую книгу посоветуешь?'},{q:'Что раздражает в людях?'},{q:'Какой комплимент запомнился?'},{q:'Чего не делал но хотел бы?'},{q:'Самое смелое что делал?'},{q:'Какую привычку изменить?'},{q:'Что ценишь в друзьях?'},{q:'Лучший день в жизни?'},{q:'Чем гордишься?'},{q:'Что для тебя роскошь?'},{q:'Как справляешься со стрессом?'},{q:'Особенное место?'},{q:'Что сделал бы с миллионом?'},{q:'Занятие в одиночестве?'},{q:'Что смешит?'},{q:'Любимая еда?'},{q:'О чём говоришь часами?'}]},
      {id:2,title:'Отношения',desc:'Про нас',color:'l2',icon:'💙',questions:[{q:'Что нравится в наших отношениях?'},{q:'Когда понял что я особенный?'},{q:'Что делаю от чего тепло?'},{q:'Любимое наше воспоминание?'},{q:'Чего хотел бы больше?'},{q:'Как чувствуешь мою любовь?'},{q:'Что во мне удивляет?'},{q:'Самый смешной наш момент?'},{q:'Когда мной гордишься?'},{q:'Что изменил бы в начале?'},{q:'Как видишь нас через 5 лет?'},{q:'Что для тебя верность?'},{q:'Когда со мной спокойнее?'},{q:'Главное качество во мне?'},{q:'Что раздражает во мне?'},{q:'Как понять что тебе плохо?'},{q:'Что хочешь чтобы знал?'},{q:'Когда скучаешь?'},{q:'Идеальное свидание?'},{q:'Как проявляешь любовь?'},{q:'Чего боишься в отношениях?'},{q:'Что важно обсудить но сложно?'},{q:'Любимая традиция?'},{q:'Когда злишься на меня?'},{q:'Что могу делать лучше?'},{q:'Как поддержать тебя?'},{q:'Что не рассказывал о нас?'},{q:'Когда чувствуешь себя любимым?'},{q:'Что для тебя предательство?'},{q:'Какая мелочь радует?'},{q:'Что думаешь о будущем?'},{q:'Что изменилось благодаря нам?'},{q:'Как справляешься с ревностью?'},{q:'Когда скучал сильнее всего?'},{q:'Что делает нас особенными?'}]},
      {id:3,title:'Глубже',desc:'Эмоции и страхи',color:'l3',icon:'🔥',questions:[{q:'Самый большой страх?'},{q:'Что ранит сильнее всего?'},{q:'О чём жалеешь?'},{q:'Когда плакал последний раз?'},{q:'Что скрываешь от других?'},{q:'Какая травма влияет?'},{q:'Чего стыдишься?'},{q:'Когда чувствуешь одиночество?'},{q:'Что изменил бы в прошлом?'},{q:'Какой момент сломал?'},{q:'Что не можешь простить себе?'},{q:'Когда притворяешься?'},{q:'Что пугает в будущем?'},{q:'О чём мечтаешь но боишься сказать?'},{q:'Когда был на грани?'},{q:'Что разрушило бы тебя?'},{q:'Какую ложь поддерживаешь?'},{q:'Чего избегаешь?'},{q:'Что делает уязвимым?'},{q:'Какие мысли мучают ночью?'},{q:'Что потерял и не отпустил?'},{q:'Когда предавал себя?'},{q:'Что скрываешь от меня?'},{q:'Тёмный секрет?'},{q:'Когда ненавидел себя?'},{q:'Что сложно принять во мне?'},{q:'Какая боль сформировала?'},{q:'О чём не можешь говорить?'},{q:'Что боишься потерять?'},{q:'Когда чувствуешь себя ненужным?'},{q:'Что держит без сна?'},{q:'Самый трудный выбор?'},{q:'Что не сказал важным людям?'},{q:'Когда был слабым?'},{q:'Какой урок дался сложнее всего?'}]},
      {id:4,title:'Близость',desc:'Желания',color:'l4',icon:'💕',questions:[{q:'Что возбуждает во мне?'},{q:'Любимое прикосновение?'},{q:'Что хотел бы попробовать?'},{q:'Когда хочешь меня больше всего?'},{q:'Что особенно нравится?'},{q:'Любимая часть тела?'},{q:'Что смущает в интиме?'},{q:'Лучший наш раз?'},{q:'Что хотел бы чаще?'},{q:'Как понять что в настроении?'},{q:'Что любишь перед близостью?'},{q:'Идеальная обстановка?'},{q:'Что отвлекает во время?'},{q:'Утром или вечером?'},{q:'Что хотел бы чтобы инициировал?'},{q:'Какой темп нравится?'},{q:'Что думаешь об игрушках?'},{q:'Как нравится целоваться?'},{q:'Что чувствуешь после?'},{q:'Идеальная прелюдия?'},{q:'Место где хотел бы?'},{q:'Что думаешь о ролевых?'},{q:'Какой наряд заводит?'},{q:'Что нужно чтобы расслабиться?'},{q:'Как нравится когда трогают?'},{q:'Что никогда не попробовал бы?'},{q:'Какие слова возбуждают?'},{q:'Что для тебя оргазм?'},{q:'Как часто хотел бы?'},{q:'Что улучшило бы интим?'},{q:'Доминировать или подчиняться?'},{q:'Что фантазируешь обо мне?'},{q:'Какой эксперимент интригует?'},{q:'Любимая поза?'},{q:'Что делает секс незабываемым?'}]},
      {id:5,title:'Без табу',desc:'Фантазии',color:'l5',icon:'🔞',questions:[{q:'Главная фантазия?'},{q:'Что хотел бы чтобы сделал с тобой?'},{q:'Смотришь порно? Какое?'},{q:'Что заводит но стесняешься?'},{q:'Пробовал необычное раньше?'},{q:'Лучший секс в жизни?'},{q:'Что думаешь о сексе втроём?'},{q:'Есть фетиш о котором молчишь?'},{q:'Что хотел бы чтобы надел?'},{q:'Нравится смотреть на себя?'},{q:'Какие игрушки попробовать?'},{q:'Что думаешь об анальном?'},{q:'Нравится боль?'},{q:'Хотел бы быть связанным?'},{q:'Секс в публичном месте?'},{q:'Идеальный сценарий?'},{q:'Что сделал бы без границ?'},{q:'Нравится dirty talk?'},{q:'Какое видео хотел бы?'},{q:'Что думаешь о свинге?'},{q:'Попробовать БДСМ?'},{q:'Секс-вечеринки?'},{q:'Какую роль сыграть?'},{q:'Что заводит в других?'},{q:'Думал о сексе с другом?'},{q:'Самый грязный секрет?'},{q:'Что снять на видео?'},{q:'Идея измены в игре?'},{q:'Что думаешь об оргии?'},{q:'Самая дикая вещь?'},{q:'Что попробовать только раз?'},{q:'О ком фантазируешь?'},{q:'Какой твой предел?'},{q:'Самое постыдное желание?'},{q:'Что пугает и возбуждает?'}]},
      {id:6,title:'Запретное',desc:'Тёмные желания',color:'l6',icon:'⛓️',questions:[{q:'Что возбуждает но пугает?'},{q:'Что сделал бы если никто не узнает?'},{q:'Какой запрет нарушить?'},{q:'Что привлекает в опасности?'},{q:'Постыдное что заводит?'},{q:'Что попросил бы не боясь?'},{q:'Самая тёмная часть тебя?'},{q:'Что скрываешь от себя?'},{q:'Самый грязный сон?'},{q:'Что сделал бы анонимно?'},{q:'Полное подчинение?'},{q:'Привлекает насилие?'},{q:'Какую границу пересечь?'},{q:'Что заводит в унижении?'},{q:'Думал о незаконном?'},{q:'Самый тёмный фетиш?'},{q:'Что сделал бы с властью?'},{q:'Привлекает боль другого?'},{q:'Какая фантазия пугает?'},{q:'Что подавляешь?'},{q:'Какой опыт сломал бы?'},{q:'Полная потеря контроля?'},{q:'Самая опасная версия тебя?'},{q:'Что сделал бы без последствий?'},{q:'Какое желание разрушает?'},{q:'Что скрываешь от всех?'},{q:'Личный ад?'},{q:'Что сделал бы ради удовольствия?'},{q:'Какая часть хочет выйти?'},{q:'Что никогда не скажешь?'},{q:'Предел боли?'},{q:'Что заводит в запретном?'},{q:'Финальный секрет?'},{q:'Самое тёмное желание?'},{q:'Что сделаешь если разрешу всё?'}]}
    ],
    positions: [
      {name:'Миссионерская',icon:'🙏',diff:1,cat:'classic',desc:'Классика лицом к лицу',howTo:['Она на спине','Он сверху','Ноги обхватывают'],tip:'Подушка под бёдра',variants:['Ноги на плечи','С подушкой']},
      {name:'Наездница',icon:'🏇',diff:1,cat:'classic',desc:'Она сверху, полный контроль',howTo:['Он на спине','Она сверху','Вперёд-назад'],tip:'Для клитора вперёд-назад',variants:['Откинуться','Круговые']},
      {name:'Догги-стайл',icon:'🐕',diff:1,cat:'classic',desc:'Она на четвереньках',howTo:['Она на четвереньках','Он сзади'],tip:'Грудь вниз = глубже',variants:['Грудь вниз','Стоя']},
      {name:'Ложки',icon:'🥄',diff:1,cat:'intimate',desc:'Оба на боку, нежно',howTo:['Оба на боку','Он сзади'],tip:'Для утра',variants:['С ласками']},
      {name:'Обратная наездница',icon:'🔄',diff:1,cat:'classic',desc:'Она спиной сверху',howTo:['Он на спине','Она спиной'],tip:'Осторожно с резкими движениями',variants:['Наклон вперёд']},
      {name:'69',icon:'6️⃣',diff:2,cat:'oral',desc:'Взаимный оральный',howTo:['Один на спине','Второй сверху противоположно'],tip:'Чередуйтесь',variants:['Она сверху','На боку']},
      {name:'Прон-боун',icon:'🦴',diff:1,cat:'classic',desc:'Она на животе',howTo:['Она на животе','Он сверху сзади'],tip:'Подушка под бёдра',variants:['С подушкой']},
      {name:'Лотос',icon:'🪷',diff:2,cat:'intimate',desc:'Тантрическая близость',howTo:['Он скрестив ноги','Она на него'],tip:'Дышите вместе',variants:['Медленно']},
      {name:'Бабочка',icon:'🦋',diff:2,cat:'classic',desc:'Она на краю, он держит ноги',howTo:['Она на краю','Он стоит'],tip:'Угол влияет на ощущения',variants:['Ноги вместе']},
      {name:'Стоя у стены',icon:'🧱',diff:2,cat:'standing',desc:'Страсть у стены',howTo:['Она у стены','Он держит'],tip:'На одной ноге легче',variants:['На одной ноге']},
      {name:'На стуле',icon:'🪑',diff:2,cat:'furniture',desc:'Он на стуле',howTo:['Он сидит','Она сверху'],tip:'Стул даёт опору',variants:['Лицом','Спиной']},
      {name:'Глубокий удар',icon:'💫',diff:2,cat:'deep',desc:'Колени к груди',howTo:['Она на спине','Колени к груди'],tip:'Осторожно — глубоко!',variants:['Ноги за голову']},
      {name:'Амазонка',icon:'👸',diff:3,cat:'athletic',desc:'Она на корточках',howTo:['Он на спине','Она на корточках'],tip:'Утомительно!',variants:['Лицом','Спиной']},
      {name:'Ножницы',icon:'✂️',diff:2,cat:'intimate',desc:'Ноги переплетены',howTo:['Под углом','Ноги переплетены'],tip:'Для медленного',variants:['На боку']},
      {name:'Танец на коленях',icon:'💃',diff:2,cat:'intimate',desc:'Оба на коленях',howTo:['Оба на коленях','Она спиной'],tip:'Ласкает грудь и клитор',variants:['Перед зеркалом']},
      {name:'Арка',icon:'🏛️',diff:3,cat:'athletic',desc:'Она выгибается',howTo:['Он на коленях','Она выгибается'],tip:'Требует гибкости',variants:['Меньший прогиб']},
      {name:'Мостик',icon:'🌉',diff:3,cat:'athletic',desc:'Она в мостике',howTo:['Она в мостике','Он между ног'],tip:'Только для гибких!',variants:['Неполный']},
      {name:'Водопад',icon:'🌊',diff:3,cat:'athletic',desc:'Голова свисает',howTo:['Он головой с края','Она сверху'],tip:'Макс 2-3 мин!',variants:['Перед оргазмом']},
      {name:'Стоя сзади',icon:'🚿',diff:2,cat:'standing',desc:'Для душа',howTo:['Она наклоняется','Он сзади'],tip:'Осторожно в душе',variants:['В душе']},
      {name:'Подъём',icon:'🏋️',diff:3,cat:'standing',desc:'Он держит на весу',howTo:['Он поднимает','Она обхватывает'],tip:'Требует силы!',variants:['У стены']},
      {name:'В машине',icon:'🚗',diff:2,cat:'special',desc:'Заднее сиденье',howTo:['Заднее сиденье','Наездница'],tip:'Тонировка!',variants:['Наездница']},
      {name:'Молитва',icon:'🧎',diff:2,cat:'kneeling',desc:'Она на пятках',howTo:['Она на пятках','Наклон вперёд'],tip:'Очень глубоко',variants:['Руки вытянуты']},
      {name:'Тачка',icon:'🛒',diff:3,cat:'athletic',desc:'Он держит за ноги',howTo:['Она на руках','Он держит ноги'],tip:'Для смеха',variants:['На локтях']},
      {name:'Звезда',icon:'⭐',diff:1,cat:'special',desc:'Она раскинута',howTo:['Она раскинута','Он сверху'],tip:'Полное доверие',variants:['С БДСМ']},
      {name:'На диване',icon:'📺',diff:1,cat:'sitting',desc:'Удобно и долго',howTo:['Он на диване','Она сверху'],tip:'Для долгого',variants:['Лицом','Спиной']},
      {name:'Вертолёт',icon:'🚁',diff:3,cat:'athletic',desc:'Она вращается',howTo:['Из наездницы','Медленно поворачивается'],tip:'Очень сложно!',variants:['На 90°']},
      {name:'Скрутка',icon:'🌀',diff:2,cat:'special',desc:'Бёдра повёрнуты',howTo:['Она на спине','Бёдра в сторону'],tip:'Необычные ощущения',variants:['Другая сторона']},
      {name:'Краб',icon:'🦀',diff:3,cat:'special',desc:'Оба в позе краба',howTo:['Оба в позе краба','Навстречу'],tip:'Для смеха',variants:['Для смеха']},
      {name:'Колыбель',icon:'🤱',diff:1,cat:'intimate',desc:'Нежные объятия',howTo:['Он сидит','Она на колени'],tip:'Для близости',variants:['Медленно']},
      {name:'На краю',icon:'🛏️',diff:1,cat:'classic',desc:'Она на краю кровати',howTo:['Она на краю','Он стоит'],tip:'Подушки для высоты',variants:['Ноги на плечах']}
    ],
    tests: [
      {id:'compat',title:'Совместимость',desc:'Насколько вы подходите',time:'5 мин',questions:[{q:'Идеальный вечер?',opts:['Дома','С друзьями','Каждый своим','Активно']},{q:'Ссоры нужно...',opts:['Обсуждать','Остыть','Забыть','Писать']},{q:'Деньги...',opts:['На впечатления','Копить','Инвестировать','На комфорт']},{q:'Дети?',opts:['Обязательно','Может быть','Не уверен','Нет']},{q:'Домашние дела?',opts:['Поровну','Кто свободен','Свои','Нанимаем']}]},
      {id:'love',title:'Язык любви',desc:'Как выражаете любовь',time:'5 мин',questions:[{q:'Чувствую любовь когда...',opts:['Говорят','Обнимают','Дарят','Помогают','Время']},{q:'Показываю через...',opts:['Слова','Прикосновения','Подарки','Помощь','Время']},{q:'Расстраивает...',opts:['Не говорят','Мало обнимают','Забывают','Не помогают','Нет времени']}]},
      {id:'intimate',title:'Интимность',desc:'Желания в постели',time:'5 мин',questions:[{q:'Инициатива от...',opts:['Меня','Партнёра','Поровну','По-разному']},{q:'Частота?',opts:['Каждый день','3-4 в неделю','1-2','По настроению']},{q:'Эксперименты?',opts:['Люблю','Иногда','Привычное','От партнёра']},{q:'После секса?',opts:['Обниматься','Говорить','Спать','Повторить']}]},
      {id:'values',title:'Ценности',desc:'Что важно',time:'5 мин',questions:[{q:'Семья?',opts:['Главное','Важно','Создаём свою','Каждый решает']},{q:'Религия?',opts:['Важна','Уважаю','Не важна','Ищу путь']},{q:'Верность?',opts:['Физ и эмоц','Только физ','Честность','Обсуждаемо']}]},
      {id:'fantasy',title:'Фантазии',desc:'Тайные желания',time:'5 мин',questions:[{q:'Ролевые игры?',opts:['Хочу','Иногда','Не моё','Практикуем']},{q:'Игрушки?',opts:['Да','Некоторые','Нет','Используем']},{q:'Втроём?',opts:['Фантазия','С правилами','Нет','Был опыт']},{q:'БДСМ?',opts:['Интересно','Лёгкое','Нет','Практикуем']}]}
    ],
    tips: [
      {icon:'her',cat:'Для неё',title:'Точка G',content:'На передней стенке, 3-5 см',steps:['Палец вверх','Ребристая область','Движения иди сюда']},
      {icon:'her',cat:'Для неё',title:'Клитор',content:'8000 нервных окончаний',steps:['Непрямая стимуляция','Увлажнение','Ритм важнее скорости']},
      {icon:'him',cat:'Для него',title:'Контроль',content:'Техники продления',steps:['Стоп-старт','Сжать основание','Глубокое дыхание']},
      {icon:'both',cat:'Вместе',title:'Синхронный оргазм',content:'Одновременно',steps:['Изучить сигналы','Говорить я близко','Кто ближе замедляется']}
    ],
    ideas: [
      {cat:'🌹 Романтика',items:['Ужин при свечах','Ванна','Массаж','Танец','Завтрак в постель']},
      {cat:'🔥 Прелюдия',items:['Эротический массаж','Стриптиз','Душ вместе','Секстинг','Карты на раздевание']},
      {cat:'🎭 Ролевые',items:['Незнакомцы в баре','Босс и секретарь','Врач','Массажист','Фотограф']},
      {cat:'📍 Места',items:['Кухня','Балкон','Машина','Примерочная','Отель']},
      {cat:'🎲 Игры',items:['Правда или действие','На раздевание','Кубики','Фанты','Час контроля']}
    ],
    challenges: [
      {title:'7 дней страсти',desc:'Секс каждый день',days:7,icon:'🔥',points:100},
      {title:'Комплименты',desc:'3 в день',days:7,icon:'💬',points:50},
      {title:'Массаж',desc:'Каждый вечер',days:7,icon:'💆',points:60},
      {title:'5 новых поз',desc:'Попробовать',days:5,icon:'🔄',points:75},
      {title:'Без телефонов',desc:'Вечер вдвоём',days:1,icon:'📵',points:30}
    ],
    allWishes: ['💋 Долгие поцелуи','🔥 Страстный секс','🥰 Нежный секс','👅 Куннилингус','🍆 Минет','🙃 69','🍑 Анальный секс','🔗 Связывание','👀 Повязка на глаза','👋 Шлепки','🎭 Ролевая игра','📍 Необычное место','🚿 В душе','🚗 В машине','📸 Фотосессия','📹 Видео','💬 Dirty talk','🎲 Секс-игра','🍷 Ужин + секс','🏨 Отель','👸 Она доминирует','🧎 Он подчиняется','👊 БДСМ','🧴 Массаж + секс','🧊 Лёд','⏱️ Долгая прелюдия','😴 Разбудить сексом','💪 Жёстко','🌙 При свечах','🪞 Перед зеркалом'],
    pregnancyInfo: {weeks:[{week:4,size:'🌰',sizeName:'Зерно',tips:['Тест','Фолиевая кислота']},{week:12,size:'🍋',sizeName:'Лайм',tips:['Скрининг','Токсикоз проходит']},{week:20,size:'🍌',sizeName:'Банан',tips:['УЗИ','Шевеления']},{week:40,size:'🍉',sizeName:'Арбуз',tips:['Срок!','Скоро!']}],safePositions:['Ложки','Наездница','На краю'],warnings:['Без давления на живот','Не на спине после 20 нед']}
  });
});

app.listen(PORT, () => console.log('Explore API v2 on port ' + PORT));
